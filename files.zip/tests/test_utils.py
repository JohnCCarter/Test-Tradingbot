from modules.utils import ensure_paper_trading_symbol

def test_ensure_paper_trading_symbol():
    assert ensure_paper_trading_symbol("BTC/USDT") == "BTC/USDT_PERP"