import pytest

@pytest.fixture
def sample_data():
    return {"example_key": "example_value"}