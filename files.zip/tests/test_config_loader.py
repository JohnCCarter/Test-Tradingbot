from config_loader import load_config, BotConfig
import pytest

def test_load_config():
    config = load_config("tests/sample_config.json")
    assert isinstance(config, BotConfig)