from modules.orders import place_order

def test_place_order():
    assert place_order(None, "BTC/USDT", "limit", "buy", 1, price=30000) is None