from modules.indicators import calculate_ema

def test_calculate_ema():
    assert calculate_ema([1, 2, 3], 2) is None