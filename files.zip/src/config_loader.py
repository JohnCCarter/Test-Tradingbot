from pydantic import BaseModel, ValidationError
import json

class BotConfig(BaseModel):
    logging_level: str
    api_key: str
    api_secret: str
    trading_mode: str  # e.g., "paper" or "live"

def load_config(config_path="config.json") -> BotConfig:
    try:
        with open(config_path, "r") as file:
            data = json.load(file)
            return BotConfig(**data)
    except (FileNotFoundError, ValidationError) as e:
        raise RuntimeError(f"Failed to load config: {e}")