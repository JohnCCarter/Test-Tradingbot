from config_loader import load_config
import logging

def main():
    # Load configuration
    config = load_config()

    # Initialize logger
    logging.basicConfig(level=config.logging_level)
    logger = logging.getLogger(__name__)
    logger.info("Trading bot started.")

    # Main loop
    while True:
        # Add main trading logic here
        logger.info("Running trading loop...")
        break

if __name__ == "__main__":
    main()