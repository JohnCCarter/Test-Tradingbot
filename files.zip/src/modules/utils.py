from functools import wraps
import time

def retry(retries=3, delay=1):
    """A decorator to retry function calls."""
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            for attempt in range(retries):
                try:
                    return func(*args, **kwargs)
                except Exception as e:
                    if attempt < retries - 1:
                        time.sleep(delay)
                        continue
                    raise e
        return wrapper
    return decorator

def ensure_paper_trading_symbol(symbol):
    """Ensure the symbol is valid for paper trading."""
    return symbol + "_PERP" if not symbol.endswith("_PERP") else symbol