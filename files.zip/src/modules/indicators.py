def calculate_ema(prices, period):
    """Calculate Exponential Moving Average (EMA)."""
    pass

def calculate_atr(highs, lows, closes, period):
    """Calculate Average True Range (ATR)."""
    pass

def calculate_rsi(prices, period):
    """Calculate Relative Strength Index (RSI)."""
    pass

def calculate_adx(highs, lows, closes, period):
    """Calculate Average Directional Index (ADX)."""
    pass